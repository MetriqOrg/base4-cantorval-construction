#!/usr/bin/env python3
"""Generate formula-derived artwork and figures for MF-MATH-2026-05.

The art is based on the exact middle-third Cantor construction and the identity
C+C=[0,2]. No generative imagery or numerical approximation is used for the
mathematical diagrams.
"""
from __future__ import annotations

from pathlib import Path
import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import FancyBboxPatch, Rectangle, PathPatch
from matplotlib.path import Path as MplPath

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "figures"
FIG.mkdir(parents=True, exist_ok=True)

# Metriq v3.1 palette.
MINT = "#C6F5DD"
SIGNAL = "#2AD189"
EMERALD = "#06A269"
TEAL = "#045B5D"
TEAL_LIGHT = "#0C8D8F"
BLUE = "#1972DC"
CHARCOAL = "#333333"
NEAR_BLACK = "#0B0D0E"
OFF_WHITE = "#F7FAF9"
MUTED = "#5F6B6B"
BORDER = "#D6E2DE"
WARNING = "#B36B00"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "mathtext.fontset": "dejavusans",
    "axes.unicode_minus": False,
})


def cantor_intervals(level: int) -> list[tuple[float, float]]:
    intervals = [(0.0, 1.0)]
    for _ in range(level):
        nxt: list[tuple[float, float]] = []
        for a, b in intervals:
            third = (b - a) / 3.0
            nxt.append((a, a + third))
            nxt.append((b - third, b))
        intervals = nxt
    return intervals


def bezier(ax, p0, p1, p2, p3, color, lw=0.8, alpha=0.18):
    path = MplPath([p0, p1, p2, p3], [MplPath.MOVETO, MplPath.CURVE4, MplPath.CURVE4, MplPath.CURVE4])
    ax.add_patch(PathPatch(path, facecolor="none", edgecolor=color, lw=lw, alpha=alpha))


def glow_line(ax, x0, x1, y, color):
    for lw, alpha in [(22, 0.018), (12, 0.035), (5, 0.09), (1.4, 0.70)]:
        ax.plot([x0, x1], [y, y], color=color, lw=lw, alpha=alpha, solid_capstyle="round")


def cover_art() -> None:
    width, height, dpi = 8.5, 11.0, 240
    fig = plt.figure(figsize=(width, height), dpi=dpi)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    nx, ny = 1250, 1650
    xx, yy = np.meshgrid(np.linspace(0, 1, nx), np.linspace(0, 1, ny))
    c0 = np.array([11, 13, 14], dtype=float) / 255.0
    c1 = np.array([4, 91, 93], dtype=float) / 255.0
    c2 = np.array([25, 114, 220], dtype=float) / 255.0
    c3 = np.array([42, 209, 137], dtype=float) / 255.0
    field1 = np.exp(-((xx - 0.80) ** 2 / 0.10 + (yy - 0.23) ** 2 / 0.075))
    field2 = np.exp(-((xx - 0.16) ** 2 / 0.11 + (yy - 0.12) ** 2 / 0.045))
    field3 = np.exp(-((xx - 0.53) ** 2 / 0.24 + (yy - 0.43) ** 2 / 0.12))
    bg = np.zeros((ny, nx, 3), dtype=float)
    bg[:] = c0
    bg += field1[..., None] * 0.50 * (c1 - c0)
    bg += field2[..., None] * 0.24 * (c2 - c0)
    bg += field3[..., None] * 0.10 * (c3 - c0)
    bg = np.clip(bg, 0, 1)
    ax.imshow(bg, extent=[0, 1, 0, 1], origin="lower", aspect="auto")

    # Sparse scale grid.
    for y in np.linspace(0.06, 0.49, 12):
        ax.plot([0.055, 0.945], [y, y], color="white", lw=0.32, alpha=0.028)
    for x in np.linspace(0.055, 0.945, 19):
        ax.plot([x, x], [0.055, 0.49], color="white", lw=0.32, alpha=0.020)

    # Two exact stage-7 Cantor rugs.
    intervals = cantor_intervals(7)
    x_left, x_right = 0.075, 0.925
    span = x_right - x_left

    def draw_rug(y: float, color: str, label: str):
        for a, b in intervals:
            xa = x_left + span * a
            xb = x_left + span * b
            ax.plot([xa, xb], [y, y], color=color, lw=2.0, alpha=0.88, solid_capstyle="butt")
        ax.plot([x_left, x_right], [y, y], color="white", lw=0.45, alpha=0.08)
        ax.text(x_left, y + 0.018, label, color=color, fontsize=7.1, fontweight="bold", alpha=0.78,
                ha="left", va="bottom")

    y1, y2, ys = 0.405, 0.315, 0.175
    draw_rug(y1, SIGNAL, "MIDDLE-THIRD CANTOR SET C")
    draw_rug(y2, BLUE, "SECOND COPY OF C")

    # Exact first-level triadic channels that cover [0,2].
    # Map [0,2] to the cover width. Three intervals [0,2/3], [2/3,4/3], [4/3,2].
    channels = [(0.0, 2/3, SIGNAL), (2/3, 4/3, TEAL_LIGHT), (4/3, 2.0, BLUE)]
    for a, b, color in channels:
        xa = x_left + span * (a / 2.0)
        xb = x_left + span * (b / 2.0)
        ax.add_patch(FancyBboxPatch((xa, ys - 0.015), xb - xa, 0.030,
                                    boxstyle="round,pad=0.001,rounding_size=0.004",
                                    linewidth=0.55, edgecolor="white", facecolor=color, alpha=0.44))
    glow_line(ax, x_left, x_right, ys, MINT)
    ax.text(x_left, ys + 0.028, "C + C = [0,2]", color=MINT, fontsize=8.0, fontweight="bold",
            alpha=0.90, ha="left", va="bottom")
    ax.text(x_right, ys + 0.028, "NO GAPS REMAIN", color="white", fontsize=7.0, fontweight="bold",
            alpha=0.52, ha="right", va="bottom")

    # Selected exact digit-pair flow lines. The paths are decorative but endpoints use
    # actual triadic prefix values from digits {0,2}.
    prefixes = []
    for k in range(64):
        digits = [(k >> j) & 1 for j in range(6)]
        v = sum(2 * digits[j] / (3 ** (j + 1)) for j in range(6))
        prefixes.append(v)
    prefixes = np.array(sorted(prefixes))
    sample_idx = [4, 11, 20, 31, 43, 55, 61]
    for idx, jdx in zip(sample_idx, reversed(sample_idx)):
        a = prefixes[idx]
        b = prefixes[jdx]
        s = a + b
        xa = x_left + span * a
        xb = x_left + span * b
        xs = x_left + span * (s / 2.0)
        bezier(ax, (xa, y1 - 0.006), (xa, 0.355), (xs, 0.245), (xs, ys + 0.010), SIGNAL, lw=0.65, alpha=0.18)
        bezier(ax, (xb, y2 - 0.006), (xb, 0.265), (xs, 0.225), (xs, ys + 0.010), BLUE, lw=0.65, alpha=0.18)

    # Threshold marker and reciprocal-scale motif.
    tx = 0.50
    ax.plot([tx, tx], [0.09, 0.455], color="white", lw=0.65, alpha=0.10)
    for radius, color, alpha in [(0.080, SIGNAL, 0.08), (0.052, BLUE, 0.10), (0.028, MINT, 0.15)]:
        theta = np.linspace(-0.2 * math.pi, 1.2 * math.pi, 240)
        ax.plot(tx + radius * np.cos(theta), 0.505 + radius * np.sin(theta), color=color, lw=0.7, alpha=alpha)

    # Lower signal trace.
    x = np.linspace(0.055, 0.945, 2000)
    y = 0.070 + 0.0055 * np.sin(65 * x) * np.exp(-3.0 * (x - 0.5) ** 2)
    for lw, alpha in [(8, 0.014), (3.2, 0.04), (0.8, 0.28)]:
        ax.plot(x, y, color=SIGNAL, lw=lw, alpha=alpha)

    fig.savefig(FIG / "cover_art.png", dpi=dpi, facecolor=NEAR_BLACK, bbox_inches=None, pad_inches=0)
    plt.close(fig)


def cantor_sum_figure() -> None:
    fig, ax = plt.subplots(figsize=(7.25, 4.45), dpi=220)
    ax.set_xlim(-0.03, 2.03)
    ax.set_ylim(0, 1)
    ax.axis("off")

    level = 5
    intervals = cantor_intervals(level)

    def draw_intervals(y, offset, scale, color, height=0.065):
        for a, b in intervals:
            ax.add_patch(Rectangle((offset + scale * a, y - height / 2), scale * (b - a), height,
                                   facecolor=color, edgecolor=color, lw=0.2, alpha=0.86))

    draw_intervals(0.78, 0.0, 1.0, SIGNAL)
    draw_intervals(0.54, 0.0, 1.0, BLUE)

    # Sum interval and exact first-level decomposition.
    y = 0.19
    pieces = [(0.0, 2/3, SIGNAL), (2/3, 4/3, TEAL_LIGHT), (4/3, 2.0, BLUE)]
    for a, b, color in pieces:
        ax.add_patch(FancyBboxPatch((a, y - 0.055), b - a, 0.11,
                                    boxstyle="round,pad=0.002,rounding_size=0.018",
                                    facecolor=color, edgecolor="white", linewidth=0.8, alpha=0.72))
    ax.plot([0, 2], [y, y], color=CHARCOAL, lw=0.8, alpha=0.5)

    ax.text(0, 0.91, r"stage-5 approximation to $C$", color=EMERALD, fontsize=11, fontweight="bold", ha="left")
    ax.text(0, 0.67, r"a second copy of $C$", color=BLUE, fontsize=11, fontweight="bold", ha="left")
    ax.text(0, 0.35, r"the three first-level sum channels have adjacent convex hulls", color=TEAL, fontsize=10.6,
            fontweight="bold", ha="left")
    ax.text(1/3, 0.19, r"$0+C/3+C/3$", color="white", fontsize=8.7, ha="center", va="center")
    ax.text(1.0, 0.19, r"$2/3+C/3+C/3$", color="white", fontsize=8.7, ha="center", va="center")
    ax.text(5/3, 0.19, r"$4/3+C/3+C/3$", color="white", fontsize=8.7, ha="center", va="center")
    ax.text(0, 0.055, "0", color=MUTED, fontsize=9, ha="center")
    ax.text(2, 0.055, "2", color=MUTED, fontsize=9, ha="center")
    ax.text(1, 0.055, r"$C+C=[0,2]$", color=CHARCOAL, fontsize=12, fontweight="bold", ha="center")

    fig.savefig(FIG / "cantor_sumset.pdf", bbox_inches="tight")
    fig.savefig(FIG / "cantor_sumset.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def threshold_figure() -> None:
    fig, ax = plt.subplots(figsize=(7.25, 3.55), dpi=220)
    ax.set_xlim(0, 0.51)
    ax.set_ylim(-0.13, 1.0)
    ax.set_yticks([])
    ax.spines[["left", "right", "top"]].set_visible(False)
    ax.spines["bottom"].set_color(CHARCOAL)
    ax.set_xlabel(r"geometric ratio $q$", color=CHARCOAL, fontsize=10.5)
    ax.set_xticks([0, 1/3, 1/2])
    ax.set_xticklabels(["0", r"$1/3$", r"$1/2$"])

    ax.axvspan(0, 1/3, ymin=0.16, ymax=0.72, color=MINT, alpha=0.70)
    ax.axvspan(1/3, 1/2, ymin=0.16, ymax=0.72, color=BLUE, alpha=0.18)
    ax.axvline(1/3, color=WARNING, lw=2.0, alpha=0.95)
    ax.axvline(1/2, color=CHARCOAL, lw=1.0, ls="--", alpha=0.45)

    ax.text(1/6, 0.55, r"$E_q+E_q$ is a Cantor set", ha="center", va="center",
            color=TEAL, fontsize=10.5, fontweight="bold")
    ax.text(5/12, 0.55, r"$E_q+E_q=[0,2]$", ha="center", va="center",
            color=BLUE, fontsize=10.5, fontweight="bold")
    ax.text(1/3 - 0.008, 0.84, r"exact transition", ha="right", va="bottom",
            color=WARNING, fontsize=10, fontweight="bold")
    ax.text(1/3 + 0.008, 0.84, r"$q=1/3$", ha="left", va="bottom",
            color=WARNING, fontsize=10, fontweight="bold")
    ax.text(0.495, 0.93, r"fast convergence: $q<1/2$", ha="right", va="bottom",
            color=CHARCOAL, fontsize=9.2)

    # The point used in the proof.
    ax.scatter([1/3], [0.28], s=80, color=WARNING, edgecolor="white", linewidth=1.0, zorder=5)
    ax.annotate(r"$x_n=2/3^n$", xy=(1/3, 0.28), xytext=(0.22, 0.05),
                arrowprops=dict(arrowstyle="->", color=WARNING, lw=1.1),
                color=WARNING, fontsize=10, fontweight="bold")
    ax.text(0.01, -0.08, r"For every $c<3$, $(c/3)^n\to0$ at the interval-producing threshold.",
            color=MUTED, fontsize=9.5, ha="left", va="center")

    fig.savefig(FIG / "sharpness_threshold.pdf", bbox_inches="tight")
    fig.savefig(FIG / "sharpness_threshold.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def mfold_figure() -> None:
    m = 5
    b = m + 1
    fig, ax = plt.subplots(figsize=(7.25, 2.7), dpi=220)
    ax.set_xlim(-0.06, m + 0.06)
    ax.set_ylim(0, 1)
    ax.axis("off")

    y = 0.48
    palette = [SIGNAL, TEAL_LIGHT, EMERALD, BLUE, TEAL, SIGNAL]
    for d in range(m + 1):
        a = d * m / b
        bb = (d + 1) * m / b
        ax.add_patch(FancyBboxPatch((a, y - 0.10), bb - a, 0.20,
                                    boxstyle="round,pad=0.003,rounding_size=0.025",
                                    facecolor=palette[d], edgecolor="white", linewidth=0.8, alpha=0.70))
        ax.text((a + bb) / 2, y, rf"$d={d}$", color="white", fontsize=9.2,
                fontweight="bold", ha="center", va="center")
    ax.plot([0, m], [y, y], color=CHARCOAL, lw=0.8, alpha=0.45)
    ax.text(0, 0.84, rf"At $q=1/(m+1)$, the $m+1$ digit channels tile $[0,m]$ exactly (shown for $m={m}$).",
            color=CHARCOAL, fontsize=10.5, fontweight="bold", ha="left")
    ax.text(m/2, 0.12, r"the same mechanism proves sharpness of the natural constant $m+1$",
            color=MUTED, fontsize=9.5, ha="center")
    ax.text(0, 0.27, "0", color=MUTED, fontsize=8.8, ha="center")
    ax.text(m, 0.27, rf"${m}$", color=MUTED, fontsize=8.8, ha="center")

    fig.savefig(FIG / "mfold_tiling.pdf", bbox_inches="tight")
    fig.savefig(FIG / "mfold_tiling.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    cover_art()
    cantor_sum_figure()
    threshold_figure()
    mfold_figure()
    print(f"Generated figures in {FIG}")
