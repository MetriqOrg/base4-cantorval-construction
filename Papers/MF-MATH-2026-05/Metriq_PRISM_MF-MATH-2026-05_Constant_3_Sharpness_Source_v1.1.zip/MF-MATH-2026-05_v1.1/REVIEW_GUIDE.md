# Independent Mathematical Review Guide

## MF-MATH-2026-05 - Sharpness of the Exponential Constant in a Sumset Criterion for Fast Achievement Sets

**Version reviewed:** 1.1  
**Issuer:** Metriq PRISM Laboratory, a research laboratory of Metriq Foundation, Inc.  
**Status:** Candidate result; not independently peer reviewed

## Central claim

For x_n=2/3^n, the series is fast convergent, c^n r_n tends to zero for every c<3, and E(x)+E(x)=[0,2]. The manuscript also gives an m-fold analogue with sharp base m+1.

## Load-bearing review targets

1. Confirm the exact statement and intended interpretation of Problem 13 in the source survey.
2. Verify the ternary digit-splitting proof that the middle-third Cantor set satisfies C+C=[0,2].
3. Check the geometric-family phase transition at q=1/3 and the strictness of the criterion.
4. Verify the general m-fold digit-splitting construction and sharp base m+1.
5. Search for an existing sharpness observation under Cantor-set arithmetic or fast-convergent series terminology.

## Review format requested

A useful review should identify the exact theorem, lemma, equation, figure, or
page involved; distinguish fatal, repairable, and expository issues; and supply
a counterexample, correction, independent derivation, or prior-art reference
where possible. Computational checks should be reported separately from review
of the infinite argument.

## Scope limitation

A successful reproduction of the included scripts does not establish the
candidate theorem, novelty, or priority. Independent mathematical reading is
required.
