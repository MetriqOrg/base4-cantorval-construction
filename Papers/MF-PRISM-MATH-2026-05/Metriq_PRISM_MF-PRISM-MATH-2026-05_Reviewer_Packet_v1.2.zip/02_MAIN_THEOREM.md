# Main Theorem - MF-PRISM-MATH-2026-05

For x_n=2/3^n, every c<3 satisfies c^n r_n -> 0, but the achievement set is the middle-third Cantor set C and C+C=[0,2]; therefore the printed criterion cannot use any smaller constant.
