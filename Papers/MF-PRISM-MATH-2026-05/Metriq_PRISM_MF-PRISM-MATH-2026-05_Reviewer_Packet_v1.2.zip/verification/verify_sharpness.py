#!/usr/bin/env python3
"""Exact-arithmetic checks for MF-PRISM-MATH-2026-05.

The proof is symbolic and does not depend on computation. This script verifies
its finite algebraic identities and the generalized first-level tiling formula
using fractions.
"""
from __future__ import annotations

from fractions import Fraction
from itertools import product


def verify_problem_13_example(max_n: int = 10) -> None:
    # x_n = 2/3^n, remainder r_n = 1/3^n.
    for n in range(1, max_n + 1):
        x_n = Fraction(2, 3**n)
        # Compute a long exact partial tail and add its exact residual.
        partial = sum((Fraction(2, 3**k) for k in range(n + 1, max_n + 8)), Fraction(0))
        residual = Fraction(1, 3 ** (max_n + 7))
        tail = partial + residual
        expected = Fraction(1, 3**n)
        assert tail == expected, (n, tail, expected)
        assert x_n > tail
        assert x_n == 2 * tail

    total_partial = sum((Fraction(2, 3**n) for n in range(1, max_n + 8)), Fraction(0))
    total_residual = Fraction(1, 3 ** (max_n + 7))
    assert total_partial + total_residual == 1


def verify_prefix_digit_coverage(base: int, level: int) -> None:
    """Digits 0,...,base-1 give every base-adic prefix exactly once."""
    vals = {
        sum(d * base ** (level - j - 1) for j, d in enumerate(digits))
        for digits in product(range(base), repeat=level)
    }
    assert vals == set(range(base**level))


def verify_mfold_generalization(max_m: int = 8, level: int = 5) -> None:
    for m in range(2, max_m + 1):
        b = m + 1
        # x_n=m/b^n and r_n=1/b^n.
        for n in range(1, 8):
            x_n = Fraction(m, b**n)
            r_n = Fraction(1, b**n)
            assert x_n == m * r_n
            assert x_n > r_n

        # First-level digit channels are consecutive intervals of length m/b.
        intervals = [
            (Fraction(d * m, b), Fraction((d + 1) * m, b))
            for d in range(m + 1)
        ]
        assert intervals[0][0] == 0
        assert intervals[-1][1] == m
        for left, right in zip(intervals, intervals[1:]):
            assert left[1] == right[0]

        verify_prefix_digit_coverage(b, level)


def main() -> None:
    verify_problem_13_example()
    verify_prefix_digit_coverage(base=3, level=7)
    verify_mfold_generalization()
    print("Exact checks passed.")
    print("Main example: x_n=2/3^n, r_n=1/3^n, x_n=2r_n.")
    print("For every c<3, c^n r_n=(c/3)^n -> 0.")
    print("Ternary digits 0,1,2 cover every prefix; hence E(x)+E(x)=[0,2].")
    print("Generalization checked for m=2,...,8: x_n=m/(m+1)^n and mE=[0,m].")


if __name__ == "__main__":
    main()
