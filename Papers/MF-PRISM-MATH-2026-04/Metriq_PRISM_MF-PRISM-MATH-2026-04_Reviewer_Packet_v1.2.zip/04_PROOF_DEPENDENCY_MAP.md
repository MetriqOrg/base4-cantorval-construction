# Proof Dependency Map

1. **Digit residues and normalized tails** - Construct complete-residue digit sets and a normalized tail recurrence.
2. **Consecutive prefix block** - Use mixed-radix bijection and prefix bounds to obtain an explicit central interval.
3. **Separated branches** - Show recursively separated lower and upper branches and infinitely many gaps.
4. **Cantorval classification** - Combine interior and gaps.
5. **Boundary finite-state recursion** - Show each boundary branch has at most three children per level.
6. **Hausdorff cover** - Cover the boundary by at most 2*3^N cylinders with factorially shrinking diameter.
