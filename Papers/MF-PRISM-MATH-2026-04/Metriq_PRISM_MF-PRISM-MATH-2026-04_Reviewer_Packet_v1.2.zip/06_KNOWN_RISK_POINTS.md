# Known Risk Points

## Internal risk level

**High**

## Questions requiring adversarial review

1. Does the finite-state recursion cover every boundary point at every level?
2. Are interval endpoints double-counted or omitted in the branch recursion?
3. Does the bound 2*3^N remain valid for the complete boundary rather than a selected subset?
4. Is there existing variable-base work that already gives zero-dimensional Cantorval boundaries?

## Required corrections already identified

- Either prove the claimed nesting of the outer sets or remove the adjective where it is not used.
- Add an explicit truncated-boundary lemma that handles central-interval endpoints and proves the full boundary recursion.
- State why the cylinder diameter bound applies uniformly to every surviving boundary branch.
- Rerun a clean two-pass LuaLaTeX build; the audit environment completed the first pass but the second pass was unusually slow.
- Update publication metadata and proposed identifier.
