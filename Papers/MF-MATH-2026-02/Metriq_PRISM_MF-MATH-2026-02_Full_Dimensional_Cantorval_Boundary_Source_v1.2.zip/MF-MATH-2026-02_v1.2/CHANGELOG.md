# Changelog - MF-MATH-2026-02

## Version 1.2 - 16 July 2026

Metriq PRISM Laboratory edition; updated cover and masthead, institutional disclaimer, release metadata, licensing, checksums, and package organization. No mathematical claim was changed.

## Version 1.1 - 15 July 2026

Integrated audited proof revisions: exact tail identity, finite-branch formalization, protected gap endpoints and containment, prefix uniqueness, spacing, and exact product-measure masses.

## Version 1.0 - 15 July 2026

Initial candidate preprint.
