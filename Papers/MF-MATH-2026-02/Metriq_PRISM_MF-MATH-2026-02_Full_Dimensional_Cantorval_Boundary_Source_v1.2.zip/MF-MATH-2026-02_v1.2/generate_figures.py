#!/usr/bin/env python3
"""Generate cover artwork and exact finite-level figures for the preprint."""
from __future__ import annotations

from itertools import product
from pathlib import Path
import math

import numpy as np
import matplotlib.pyplot as plt
import mpmath as mp
from matplotlib.collections import LineCollection
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)


def ell(n: int) -> int:
    return n + 1


def base(n: int) -> int:
    return 2 * n + 4


def Q(n: int) -> int:
    q = 1
    for k in range(1, n + 1):
        q *= base(k)
    return q


def A(n: int) -> tuple[int, ...]:
    return tuple(range(0, 2 * ell(n), 2))


def D(n: int) -> tuple[int, ...]:
    l = ell(n)
    return tuple(range(0, 2 * l + 1, 2)) + tuple(range(2 * l + 1, 4 * l + 2, 2))


def prefixes(level: int, digit_fn=A) -> np.ndarray:
    vals = [0.0]
    for n in range(1, level + 1):
        q = Q(n)
        ds = digit_fn(n)
        vals = [v + d / q for v in vals for d in ds]
    return np.asarray(vals, dtype=float)


mp.mp.dps = 80


def e_total() -> mp.mpf:
    # Sum_{n>=1} (4n+5)/Q_n = 15 - 8*sqrt(e).
    return mp.mpf(15) - 8 * mp.sqrt(mp.e)


def c_total() -> mp.mpf:
    # Sum_{n>=1} 2n/Q_n = 40 - 24*sqrt(e).
    return mp.mpf(40) - 24 * mp.sqrt(mp.e)


def c_tail(level: int) -> float:
    partial = mp.fsum(mp.mpf(2 * n) / Q(n) for n in range(1, level + 1))
    return float(c_total() - partial)


def e_tail(level: int) -> float:
    partial = mp.fsum(mp.mpf(4 * n + 5) / Q(n) for n in range(1, level + 1))
    return float(e_total() - partial)


def make_boundary_levels() -> None:
    levels = list(range(1, 7))
    cmax = float(c_total())
    fig, ax = plt.subplots(figsize=(11.2, 4.7))
    for idx, n in enumerate(levels):
        y = len(levels) - idx
        starts = prefixes(n, A)
        width = max(c_tail(n), 0.75 / Q(n))
        segments = [((x / cmax, y), ((x + width) / cmax, y)) for x in starts]
        lc = LineCollection(segments, linewidths=max(0.25, 4.4 - 0.62 * n), alpha=0.92)
        ax.add_collection(lc)
        ax.text(-0.025, y, rf"$n={n}$", ha="right", va="center", fontsize=10)
        ax.text(1.018, y, rf"$M_n={(math.factorial(n+1)):,}$", ha="left", va="center", fontsize=9)
    ax.set_xlim(-0.10, 1.14)
    ax.set_ylim(0.35, len(levels) + 0.65)
    ax.set_yticks([])
    ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_xticklabels(["0", "0.25", "0.50", "0.75", "1"], fontsize=9)
    ax.set_xlabel("normalized position in the boundary subset $C$", fontsize=10)
    for spine in ["top", "right", "left"]:
        ax.spines[spine].set_visible(False)
    ax.grid(axis="x", alpha=0.18, linewidth=0.5)
    fig.tight_layout(pad=0.8)
    fig.savefig(FIG / "boundary_levels.pdf", bbox_inches="tight")
    fig.savefig(FIG / "boundary_levels.png", dpi=240, bbox_inches="tight")
    plt.close(fig)


def make_outer_approximations() -> None:
    levels = [1, 2, 3, 4]
    total = float(e_total())
    fig, ax = plt.subplots(figsize=(11.2, 4.1))
    for idx, n in enumerate(levels):
        y = len(levels) - idx
        starts = prefixes(n, D)
        tail = e_tail(n)
        # Merge intervals exactly at floating precision for a clean depiction.
        intervals = sorted((float(x), float(x + tail)) for x in starts)
        merged: list[list[float]] = []
        for lo, hi in intervals:
            if not merged or lo > merged[-1][1] + 1e-13:
                merged.append([lo, hi])
            else:
                merged[-1][1] = max(merged[-1][1], hi)
        segments = [((lo / total, y), (hi / total, y)) for lo, hi in merged]
        lc = LineCollection(segments, linewidths=6.2, alpha=0.92, capstyle="butt")
        ax.add_collection(lc)
        ax.text(-0.025, y, rf"$U_{n}$", ha="right", va="center", fontsize=10)
        ax.text(1.018, y, f"{len(merged)} components", ha="left", va="center", fontsize=9)
    ax.set_xlim(-0.10, 1.18)
    ax.set_ylim(0.35, len(levels) + 0.65)
    ax.set_yticks([])
    ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_xticklabels(["0", "0.25", "0.50", "0.75", "1"], fontsize=9)
    ax.set_xlabel("normalized position in the achievement set", fontsize=10)
    for spine in ["top", "right", "left"]:
        ax.spines[spine].set_visible(False)
    ax.grid(axis="x", alpha=0.18, linewidth=0.5)
    fig.tight_layout(pad=0.8)
    fig.savefig(FIG / "outer_approximations.pdf", bbox_inches="tight")
    fig.savefig(FIG / "outer_approximations.png", dpi=240, bbox_inches="tight")
    plt.close(fig)


def add_glow(base: Image.Image, layer: Image.Image, radii=(8, 20, 42), opacities=(0.5, 0.24, 0.10)) -> Image.Image:
    out = base.copy()
    for r, a in zip(radii, opacities):
        blurred = layer.filter(ImageFilter.GaussianBlur(r))
        if a != 1:
            alpha = blurred.getchannel("A").point(lambda p: int(p * a))
            blurred.putalpha(alpha)
        out = Image.alpha_composite(out, blurred)
    out = Image.alpha_composite(out, layer)
    return out


def make_cover_art() -> None:
    W, H = 2550, 3300
    yy, xx = np.mgrid[0:H, 0:W]
    # Deep charcoal-to-teal radial/linear gradient.
    top = np.array([8, 12, 14], dtype=float)
    bottom = np.array([3, 29, 31], dtype=float)
    t = (yy / H)[:, :, None]
    arr = top * (1 - t) + bottom * t
    radial = np.exp(-(((xx - 1840) / 1050) ** 2 + ((yy - 1980) / 1180) ** 2))[:, :, None]
    arr += radial * np.array([0, 35, 31], dtype=float)
    blue = np.exp(-(((xx - 470) / 900) ** 2 + ((yy - 2470) / 850) ** 2))[:, :, None]
    arr += blue * np.array([0, 12, 35], dtype=float)
    arr = np.clip(arr, 0, 255).astype(np.uint8)
    img = Image.fromarray(arr, mode="RGB").convert("RGBA")

    # Technical grid.
    grid = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grid)
    for x in range(0, W, 75):
        gd.line((x, 0, x, H), fill=(198, 245, 221, 8), width=1)
    for y in range(0, H, 75):
        gd.line((0, y, W, y), fill=(198, 245, 221, 8), width=1)
    img = Image.alpha_composite(img, grid)

    # Giant boundary-dimension numeral as a structural watermark.
    # Rendered as geometry rather than font so source remains portable.
    numeral = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    nd = ImageDraw.Draw(numeral)
    nd.rounded_rectangle((1840, 330, 1975, 1540), radius=55, fill=(25, 114, 220, 18))
    nd.rounded_rectangle((1680, 365, 1975, 510), radius=55, fill=(25, 114, 220, 18))
    img = Image.alpha_composite(img, numeral)

    # Exact finite-level construction as luminous nested bands.
    cmax = float(c_total())
    x0, x1 = 260, 2290
    band = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bd = ImageDraw.Draw(band)
    y_positions = [1620, 1770, 1920, 2070, 2220, 2370, 2520]
    colors = [
        (198, 245, 221, 230),
        (42, 209, 137, 220),
        (6, 162, 105, 215),
        (12, 141, 143, 205),
        (25, 114, 220, 200),
        (42, 209, 137, 185),
        (198, 245, 221, 155),
    ]
    for n, y, color in zip(range(1, 8), y_positions, colors):
        starts = prefixes(n, A)
        tail = c_tail(n)
        # Use subpixel accumulation through alpha-composited lines.
        width_px = max(1, int(round((tail / cmax) * (x1 - x0))))
        lw = max(1, 11 - n)
        for v in starts:
            xa = int(round(x0 + (v / cmax) * (x1 - x0)))
            xb = min(x1, xa + width_px)
            bd.line((xa, y, max(xa + 1, xb), y), fill=color, width=lw)
        # Level guide and factorial count tick.
        bd.line((x0 - 30, y, x0 - 8, y), fill=(198, 245, 221, 125), width=2)

    img = add_glow(img, band, radii=(7, 20, 55), opacities=(0.42, 0.18, 0.07))

    # Add a precise gap motif near the lower right.
    gaps = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gp = ImageDraw.Draw(gaps)
    gy = 2805
    gp.line((1310, gy, 1660, gy), fill=(247, 250, 249, 210), width=8)
    gp.line((1775, gy, 2180, gy), fill=(247, 250, 249, 210), width=8)
    gp.line((1660, gy - 22, 1660, gy + 22), fill=(42, 209, 137, 210), width=3)
    gp.line((1775, gy - 22, 1775, gy + 22), fill=(42, 209, 137, 210), width=3)
    gp.arc((1660, gy + 13, 1775, gy + 100), start=180, end=360, fill=(42, 209, 137, 190), width=3)
    img = add_glow(img, gaps, radii=(5, 14), opacities=(0.35, 0.12))

    # Fine particles sampled from the level-7 endpoint distribution.
    pts = prefixes(7, A)
    rng = np.random.default_rng(20260715)
    sample = rng.choice(pts, size=min(9000, len(pts)), replace=False)
    particles = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    pd = ImageDraw.Draw(particles)
    for v in sample:
        px = int(x0 + (v / cmax) * (x1 - x0))
        py = int(2450 + rng.normal(0, 155))
        radius = 1 if rng.random() < 0.93 else 2
        alpha = int(rng.integers(18, 70))
        pd.ellipse((px - radius, py - radius, px + radius, py + radius), fill=(198, 245, 221, alpha))
    img = Image.alpha_composite(img, particles)

    # Vignette.
    v = np.minimum.reduce([xx / 360, (W - 1 - xx) / 360, yy / 430, (H - 1 - yy) / 430])
    v = np.clip(v, 0, 1)
    alpha = ((1 - v) * 145).astype(np.uint8)
    vignette = Image.fromarray(np.dstack([np.zeros_like(alpha), np.zeros_like(alpha), np.zeros_like(alpha), alpha]), "RGBA")
    img = Image.alpha_composite(img, vignette)

    out = FIG / "cover_art.png"
    img.convert("RGB").save(out, quality=96, dpi=(300, 300))


if __name__ == "__main__":
    make_boundary_levels()
    make_outer_approximations()
    make_cover_art()
    print(f"Generated figures in {FIG}")
