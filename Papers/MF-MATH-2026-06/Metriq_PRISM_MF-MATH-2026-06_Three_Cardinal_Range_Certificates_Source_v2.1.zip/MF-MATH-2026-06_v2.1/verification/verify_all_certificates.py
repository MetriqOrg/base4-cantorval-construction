#!/usr/bin/env python3
"""Exact verification for MF-MATH-2026-06 Version 2.1.

Independently checks all three finite certificates by dynamic polynomial
multiplication and exhaustive subset enumeration. All proof-critical arithmetic
is integral or rational.
"""
from __future__ import annotations

from collections import Counter
from fractions import Fraction
from itertools import product

CERTIFICATES = {
    "A": {
        "sequence": (1, 2, 2, 3, 3),
        "expected": (1, 1, 2, 4, 3, 5, 5, 3, 4, 2, 1, 1),
        "range": {1, 2, 3, 4, 5},
        "zeros": (),
    },
    "B": {
        "sequence": (1, 1, 2, 2, 3, 6),
        "expected": (1, 2, 3, 5, 5, 5, 6, 5, 5, 6, 5, 5, 5, 3, 2, 1),
        "range": {1, 2, 3, 5, 6},
        "zeros": (),
    },
    "C": {
        "sequence": (2, 5, 6, 9, 10, 11, 13),
        "expected": (
            1,0,1,0,0,1,1,1,1,1,1,3,1,3,1,3,3,3,3,3,3,4,4,3,5,3,5,4,4,
            4,5,3,5,3,4,4,3,3,3,3,3,3,1,3,1,3,1,1,1,1,1,1,0,0,1,0,1,
        ),
        "range": {1, 3, 4, 5},
        "zeros": (1, 3, 4, 52, 53, 55),
    },
}


def polynomial_coefficients(sequence: tuple[int, ...]) -> tuple[int, ...]:
    coeff = [1]
    for atom in sequence:
        nxt = [0] * (len(coeff) + atom)
        for exponent, value in enumerate(coeff):
            nxt[exponent] += value
            nxt[exponent + atom] += value
        coeff = nxt
    return tuple(coeff)


def direct_subset_counts(sequence: tuple[int, ...]) -> tuple[int, ...]:
    counter: Counter[int] = Counter()
    for bits in product((0, 1), repeat=len(sequence)):
        counter[sum(bit * atom for bit, atom in zip(bits, sequence))] += 1
    return tuple(counter[t] for t in range(sum(sequence) + 1))


def representations(sequence: tuple[int, ...], target: int) -> set[tuple[int, ...]]:
    out: set[tuple[int, ...]] = set()
    for bits in product((0, 1), repeat=len(sequence)):
        if sum(bit * atom for bit, atom in zip(bits, sequence)) == target:
            out.add(tuple(atom for bit, atom in zip(bits, sequence) if bit))
    return out


def verify_certificate(name: str, data: dict[str, object]) -> tuple[int, ...]:
    sequence = data["sequence"]
    assert isinstance(sequence, tuple)
    expected = data["expected"]
    assert isinstance(expected, tuple)
    dp = polynomial_coefficients(sequence)
    direct = direct_subset_counts(sequence)
    assert dp == direct == expected
    assert len(dp) == sum(sequence) + 1
    assert sum(dp) == 2 ** len(sequence)
    assert dp == dp[::-1]
    assert {value for value in dp if value > 0} == data["range"]
    assert tuple(i for i, value in enumerate(dp) if value == 0) == data["zeros"]
    print(f"Certificate {name}: PASS")
    print(f"  sequence: {sequence}")
    print(f"  coefficient range: {sorted(data['range'])}")
    print(f"  coefficient total: {sum(dp)} = 2^{len(sequence)}")
    print(f"  zero coefficients: {data['zeros']}")
    return dp


def verify_third_samples(coeff: tuple[int, ...]) -> None:
    c = CERTIFICATES["C"]["sequence"]
    assert isinstance(c, tuple)
    assert coeff[11] == 3 and representations(c, 11) == {(11,), (5, 6), (2, 9)}
    assert coeff[21] == 4 and representations(c, 21) == {
        (10, 11), (5, 6, 10), (2, 9, 10), (2, 6, 13)
    }
    assert coeff[24] == 5 and representations(c, 24) == {
        (11, 13), (5, 9, 10), (5, 6, 13), (2, 9, 13), (2, 5, 6, 11)
    }
    assert 2 not in coeff
    print("Certificate C representative fibers and missing multiplicity 2: PASS")


def verify_cantor_tail() -> None:
    total = Fraction(1, 2)
    assert total < 1
    for n in range(1, 50):
        term = Fraction(1, 3**n)
        later_tail = Fraction(1, 2 * 3**n)
        assert term > later_tail
    print("Cantor tail uniqueness and disjoint integer translates: PASS")


def main() -> None:
    print("MF-MATH-2026-06 Version 2.1 exact verification")
    print("================================================")
    results: dict[str, tuple[int, ...]] = {}
    for name, data in CERTIFICATES.items():
        results[name] = verify_certificate(name, data)
    verify_third_samples(results["C"])
    verify_cantor_tail()
    print("ALL EXACT CHECKS PASSED")


if __name__ == "__main__":
    main()
