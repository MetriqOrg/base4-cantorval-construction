# Changelog - MF-MATH-2026-06

## Version 2.1 - 16 July 2026

Metriq PRISM Laboratory edition; updated cover and masthead, institutional disclaimer, combined exact verification, release metadata, licensing, checksums, and package organization. No mathematical claim was changed from Version 2.0.

## Version 2.0 - 15 July 2026

Consolidated the seven-atom {1,3,4,5} certificate previously circulated in two duplicate working manuscripts. The draft identified as MF-MATH-2026-07 and a mislabelled duplicate file containing 2026-08 in its filename were superseded and are not separate contributions.

## Version 1.0 - 15 July 2026

Initial paper with two finite certificates.
