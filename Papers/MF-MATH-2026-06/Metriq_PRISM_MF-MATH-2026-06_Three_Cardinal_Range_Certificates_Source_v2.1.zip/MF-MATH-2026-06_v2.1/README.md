# Finite Certificates for Three Unresolved Cardinal-Function Ranges

**Issuer:** Metriq PRISM Laboratory  
**Expanded name:** Program for Research in Intelligent Systems and Methods  
**Ownership:** A research laboratory of Metriq Foundation, Inc.  
**Identifier:** MF-MATH-2026-06  
**Version:** 2.1  
**Release date:** 16 July 2026  
**Status:** Candidate research preprint; not independently peer reviewed

## Candidate result

Three exact finite subset-sum certificates for cardinal-function ranges printed as unresolved, together with a common Cantorization theorem preserving all representation counts.

The finite witnesses (1,2,2,3,3), (1,1,2,2,3,6), and (2,5,6,9,10,11,13) realize the positive coefficient ranges {1,2,3,4,5}, {1,2,3,5,6}, and {1,3,4,5}, respectively; each admits a Cantor achievement-set extension with the same range.

## Review status

The first two certificates were internally audited without correction; the third is exactly verified by polynomial multiplication and exhaustive enumeration. Independent specialist review of novelty and table interpretation remains outstanding.

The exact finite computations supplied with the package are reproducibility and
consistency checks. They do not constitute independent validation of the
infinite arguments, novelty, or publication priority.

## Package contents

- `metriq_cardinal_range_certificates_preprint.tex` - complete LuaLaTeX manuscript source
- `release/Metriq_PRISM_MF-MATH-2026-06_Three_Cardinal_Range_Certificates_v2.1.pdf` - final PRISM-branded PDF
- `release/Metriq_PRISM_MF-MATH-2026-06_Three_Cardinal_Range_Certificates_Cover_v2.1.png` - final cover rendered from page 1 at 300 dpi
- `figures/` - formula-derived figures used in the manuscript
- `assets/` - PRISM publication lockups used by the source
- `verification/` - exact or high-precision consistency checks and recorded output
- `REVIEW_GUIDE.md` - targeted independent-review checklist
- `CITATION.cff` - machine-readable citation metadata
- `CHANGELOG.md` - version history and supersession notes
- `DISCLAIMER.txt` - institutional and computational-research disclaimer
- `LICENSE*` and `TRADEMARKS.md` - split licensing and brand restrictions
- `QA/` - PDF metadata, font, preflight, and renderer-parity reports

## Build

A current LuaLaTeX distribution is required. The included figures are already
built.

```bash
make paper
```

The rebuilt PDF is written to `build/`.

To regenerate the figures, install numpy, matplotlib, Pillow, then run:

```bash
python3 generate_figures.py
```

## Verification

```bash
python3 verification/verify_all_certificates.py
```

The recorded output is in `verification/verification_output.txt`.

## Institutional disclaimer and computational research declaration

This manuscript is an exploratory research preprint issued by the Metriq PRISM Laboratory, an interdisciplinary research laboratory of Metriq Foundation, Inc. PRISM—the Program for Research in Intelligent Systems and Methods—conducts research involving computational, mathematical, scientific, and machine-assisted methods.

The work was developed as part of PRISM’s experimental research program in computationally assisted mathematics. Metriq Foundation, acting through the PRISM Laboratory, directed the research process, evaluated the resulting argument, determined the form and scope of the manuscript, and accepts responsibility for its publication as a candidate result.

Generative artificial intelligence and other computational tools were used as research instruments to support construction search, symbolic and numerical analysis, literature review, proof development, verification, and manuscript preparation. Their use does not constitute independent validation of the results presented.

This manuscript has not yet undergone independent peer review and should not be regarded as an established resolution of the stated problem unless and until its arguments have been examined and confirmed by qualified mathematicians. Independent verification, criticism, replication, and identification of errors are expressly invited.

## License

Research text, original mathematical figures, and documentation are licensed
under **CC BY 4.0**. Verification code, build utilities, and figure-generation
software are licensed under the **MIT License**. Metriq and PRISM names, marks,
logos, publication lockups, and trade dress are excluded from those grants.
