#!/usr/bin/env python3
"""Generate formula-derived figures for MF-MATH-2026-09."""
from __future__ import annotations

from pathlib import Path
import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)

MINT = "#C6F5DD"
SIGNAL = "#2AD189"
EMERALD = "#06A269"
TEAL = "#045B5D"
TEAL_LIGHT = "#0C8D8F"
BLUE = "#1972DC"
CHARCOAL = "#333333"
NEAR_BLACK = "#0B0D0E"
OFF_WHITE = "#F7FAF9"
MUTED = "#5F6B6B"
BORDER = "#D6E2DE"
WARNING = "#B36B00"


def save_both(fig: plt.Figure, stem: str, dpi: int = 240) -> None:
    fig.savefig(FIG / f"{stem}.png", dpi=dpi, bbox_inches="tight", pad_inches=0.04)
    fig.savefig(FIG / f"{stem}.pdf", bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)


def make_cover() -> None:
    # Letter portrait canvas, exactly 2550 x 3300 px at 300 dpi.
    fig = plt.figure(figsize=(8.5, 11), dpi=300, facecolor=NEAR_BLACK)
    ax = fig.add_axes([0, 0, 1, 1], projection="3d", facecolor=NEAR_BLACK)
    ax.set_axis_off()
    ax.view_init(elev=24, azim=-54)

    # Deterministic type-ace-compatible coordinate tracks.  The composition is
    # illustrative; proof-critical content remains the formulas in the paper.
    steps = [
        (1,0,0),(0,1,0),(-1,0,0),(0,0,1),(0,1,0),(1,0,0),
        (0,0,-1),(0,-1,0),(0,1,0),(-1,0,0),(0,0,1),(1,0,0),
        (0,1,0),(0,0,1),(0,-1,0),(0,1,0),(0,0,-1),(0,1,0),
        (-1,0,0),(0,0,1),(1,0,0),(0,-1,0),(0,1,0),(0,0,-1),
        (0,1,0),(0,-1,0),(0,0,1),(0,1,0),(0,0,-1),(0,-1,0),
    ]
    p = np.array([0, 0, 0], dtype=float)
    pts = [p.copy()]
    for s in steps:
        p = p + np.array(s, dtype=float)
        pts.append(p.copy())
    pts = np.array(pts)

    # Reposition into the lower half of the cover.
    pts[:, 0] *= 0.82
    pts[:, 1] *= 0.75
    pts[:, 2] *= 0.90
    ax.plot(pts[:,0], pts[:,1], pts[:,2], color=MINT, linewidth=2.2, alpha=0.90)
    ax.scatter(pts[:,0], pts[:,1], pts[:,2], c=np.linspace(0, 1, len(pts)),
               cmap="winter", s=13, depthshade=False, alpha=0.95)

    # Sparse lattice grid and three coordinate projections.
    for t in range(-4, 7):
        ax.plot([t,t], [-2,8], [-2,-2], color=TEAL_LIGHT, alpha=0.10, linewidth=0.45)
        ax.plot([-4,6], [t,t], [-2,-2], color=TEAL_LIGHT, alpha=0.10, linewidth=0.45)
    ax.plot(pts[:,0], pts[:,1], np.full(len(pts), -2.0), color=BLUE, alpha=0.25, linewidth=1.0)
    ax.plot(pts[:,0], np.full(len(pts), 8.0), pts[:,2], color=SIGNAL, alpha=0.20, linewidth=0.9)
    ax.plot(np.full(len(pts), -4.0), pts[:,1], pts[:,2], color=MINT, alpha=0.18, linewidth=0.9)

    # Bessel-like rings / recurrence waves in the background.
    theta = np.linspace(0, 8 * np.pi, 500)
    r = 0.14 * theta
    xx = 4.5 + r * np.cos(theta)
    yy = 6.0 + r * np.sin(theta)
    zz = 4.2 + 0.20 * np.sin(2 * theta)
    ax.plot(xx, yy, zz, color=BLUE, alpha=0.18, linewidth=0.7)

    ax.set_xlim(-5, 8)
    ax.set_ylim(-3, 10)
    ax.set_zlim(-3, 8)
    fig.savefig(FIG / "cover_art.png", dpi=300, facecolor=NEAR_BLACK)
    plt.close(fig)


def make_walk_factorization() -> None:
    fig = plt.figure(figsize=(10.2, 4.2), facecolor="white")
    ax = fig.add_axes([0.02, 0.08, 0.96, 0.84])
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 34)
    ax.axis("off")

    ax.text(2, 31.2, "The type-ace exponential generating function factorizes by coordinate type",
            fontsize=14, fontweight="bold", color=CHARCOAL)
    ax.text(2, 28.7, "At every global step, one coordinate moves by ±1; multinomial interleaving becomes an EGF product.",
            fontsize=9.5, color=MUTED)

    cards = [
        (2, 5, 28, 19, "type a", "nonnegative, return to 0", r"$A(x)=I_1(2x)/x$", SIGNAL),
        (36, 5, 28, 19, "type c", "nonnegative, arbitrary endpoint", r"$C(x)=I_0(2x)+I_1(2x)$", TEAL_LIGHT),
        (70, 5, 28, 19, "type e", "unrestricted", r"$E(x)=e^{2x}$", BLUE),
    ]
    for x0, y0, w, h, label, desc, formula, color in cards:
        box = FancyBboxPatch((x0,y0),w,h,boxstyle="round,pad=0.6,rounding_size=1.2",
                             linewidth=1.2, edgecolor=BORDER, facecolor=OFF_WHITE)
        ax.add_patch(box)
        ax.text(x0+2, y0+h-3.8, label, fontsize=11, fontweight="bold", color=color)
        ax.text(x0+2, y0+h-7.0, desc, fontsize=8.8, color=MUTED)
        ax.text(x0+2, y0+3.2, formula, fontsize=13.5, color=CHARCOAL)

    # Tiny paths inside each card.
    paths = [
        [(0,0),(1,1),(2,0),(3,1),(4,2),(5,1),(6,0)],
        [(0,0),(1,1),(2,2),(3,1),(4,2),(5,3),(6,2)],
        [(0,0),(1,-1),(2,0),(3,-1),(4,-2),(5,-1),(6,-2)],
    ]
    for (x0,y0,w,h,*_), path, color in zip(cards, paths, [SIGNAL,TEAL_LIGHT,BLUE]):
        px = [x0+3 + 3.2*a for a,b in path]
        py = [y0+9 + 1.55*b for a,b in path]
        ax.plot(px, py, color=color, linewidth=2.0, marker="o", markersize=3.5)
        ax.plot([x0+3,x0+w-3],[y0+9,y0+9], color=BORDER, linewidth=0.8)

    ax.text(50, 1.1,
            r"$F(x)=A(x)C(x)E(x)=e^{2x}\,\frac{I_1(2x)}{x}(I_0(2x)+I_1(2x))$",
            fontsize=14.2, ha="center", color=TEAL)
    save_both(fig, "walk_factorization")


def make_operator_factorization() -> None:
    fig = plt.figure(figsize=(10.2, 4.0), facecolor="white")
    ax = fig.add_axes([0.02, 0.05, 0.96, 0.90])
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 30)
    ax.axis("off")
    ax.text(2, 27, "Ore-operator factorization converts the Bessel equation into Mathar's recurrence",
            fontsize=14, fontweight="bold", color=CHARCOAL)

    boxes = [
        (3, 9, 25, 12, "Bessel system", r"$u'=2v$", r"$v'=2u-v/x$", SIGNAL),
        (38, 9, 25, 12, "third-order operator", r"$L_3F=0$", r"$F=e^{2x}v(u+v)/x$", TEAL_LIGHT),
        (73, 9, 24, 12, "sixth-order operator", r"$L_6F=0$", r"coefficient recurrence", BLUE),
    ]
    for x0,y0,w,h,title,line1,line2,color in boxes:
        box=FancyBboxPatch((x0,y0),w,h,boxstyle="round,pad=0.8,rounding_size=1.2",
                           linewidth=1.3,edgecolor=color,facecolor=OFF_WHITE)
        ax.add_patch(box)
        ax.text(x0+w/2,y0+h-3.4,title,ha="center",fontsize=10.5,fontweight="bold",color=color)
        ax.text(x0+w/2,y0+5.5,line1,ha="center",fontsize=13.0,color=CHARCOAL)
        ax.text(x0+w/2,y0+2.4,line2,ha="center",fontsize=8.8,color=MUTED)
    for a,b,label in [(28,38,"eliminate"),(63,73,r"$(8x+3)^3L_6=Q\circ L_3$")]:
        arrow=FancyArrowPatch((a,15),(b,15),arrowstyle="-|>",mutation_scale=14,
                              linewidth=1.5,color=TEAL)
        ax.add_patch(arrow)
        ax.text((a+b)/2,17.2,label,ha="center",fontsize=8.5,color=MUTED)
    ax.text(50, 3.0,
            r"$Q=(8x+3)^2D^3-2(24x+17)(8x+3)D^2+32(24x+13)D-768$",
            ha="center",fontsize=10.4,color=CHARCOAL)
    save_both(fig, "operator_factorization")


def make_sequence_audit() -> None:
    values = np.array([1,3,11,44,188,842,3911,18692,91412,455540,2306028,11829424], dtype=float)
    n = np.arange(len(values))
    fig = plt.figure(figsize=(10.2, 4.0), facecolor="white")
    ax = fig.add_axes([0.08,0.17,0.88,0.73])
    ax.semilogy(n, values, marker="o", linewidth=1.8, markersize=4.5)
    ax.set_title("Initial type-ace walk counts reproduced from the Bessel EGF", loc="left",
                 fontsize=13.5, fontweight="bold", color=CHARCOAL)
    ax.set_xlabel("walk length n")
    ax.set_ylabel(r"$a_n$ (log scale)")
    ax.grid(True, alpha=0.20)
    for i in [0,1,2,3,4,8,11]:
        ax.annotate(f"{int(values[i]):,}", (n[i],values[i]), xytext=(0,7),
                    textcoords="offset points", ha="center", fontsize=7.5, color=MUTED)
    ax.text(0.99,0.04,"The exact verification script checks the EGF and recurrence by integer arithmetic.",
            transform=ax.transAxes,ha="right",fontsize=8.3,color=MUTED)
    save_both(fig, "sequence_audit")


if __name__ == "__main__":
    make_cover()
    make_walk_factorization()
    make_operator_factorization()
    make_sequence_audit()
    print("Generated figures in", FIG)
