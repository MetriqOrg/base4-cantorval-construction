# A Bessel-Factorization Proof of Mathar's Recurrence for Type-ace Lattice Walks

**Issuer:** Metriq PRISM Laboratory  
**Expanded name:** Program for Research in Intelligent Systems and Methods  
**Ownership:** A research laboratory of Metriq Foundation, Inc.  
**Identifier:** MF-MATH-2026-09  
**Version:** 1.0  
**Release date:** 16 July 2026  
**Status:** Candidate proof; not independently peer reviewed

## Candidate result

This paper proves the recurrence listed as conjectural in OEIS A302186 for the number of three-dimensional lattice walks of type `ace`.

For the type-ace walk counts `a_n`, the manuscript derives

```text
F(x) = exp(2x) I_1(2x)/x * (I_0(2x) + I_1(2x))
```

and an exact differential-operator factorization

```text
(8x+3)^3 L6 = Q o L3,   L3 F = 0.
```

Coefficient extraction from `L6 F = 0` gives Mathar's five-term polynomial recurrence for every `n >= 4`.

## Package contents

- `metriq_type_ace_walk_recurrence_preprint.tex` — complete LuaLaTeX manuscript
- `release/Metriq_PRISM_MF-MATH-2026-09_Type_ace_Walk_Recurrence_v1.0.pdf` — final PRISM-branded PDF
- `release/Metriq_PRISM_MF-MATH-2026-09_Type_ace_Walk_Recurrence_Cover_v1.0.png` — 300 dpi cover
- `figures/` — formula-derived cover and manuscript figures
- `assets/` — approved PRISM publication lockups
- `verification/verify_type_ace.py` — exact coefficient, recurrence, and Ore-factorization checks
- `verification/verification_output.txt` — recorded successful output
- `REVIEW_GUIDE.md` — independent-review checklist
- `LITERATURE_STATUS.md` — dated status and priority-search limitations
- `QA/` — PDF metadata, font, preflight, disclaimer, and visual-review records

## Build

A current LuaLaTeX distribution is required.

```bash
make paper
```

The rebuilt PDF is written to `build/`.

To regenerate figures:

```bash
python3 -m pip install -r requirements-figures.txt
make figures
```

## Verification

```bash
python3 verification/verify_type_ace.py
```

The script uses exact integer arithmetic for walk counts and recurrences and symbolic polynomial arithmetic for the Ore-operator identity. The recorded output checks coefficients and recurrence residuals through `n = 80`.

These calculations audit the displayed algebra. They do not constitute independent peer review, validation of novelty, or an exhaustive priority search.

## Institutional and computational-research disclaimer

This manuscript is an exploratory research preprint issued by the Metriq PRISM Laboratory, an interdisciplinary research laboratory of Metriq Foundation, Inc. PRISM—the Program for Research in Intelligent Systems and Methods—conducts research involving computational, mathematical, scientific, and machine-assisted methods. The work was developed as part of PRISM’s experimental research program in computationally assisted mathematics. Metriq Foundation, acting through the PRISM Laboratory, directed the research process, evaluated the resulting argument, determined the form and scope of the manuscript, and accepts responsibility for its publication as a candidate result. Generative artificial intelligence and other computational tools were used as research instruments to support construction search, symbolic and numerical analysis, literature review, proof development, verification, and manuscript preparation. Their use does not constitute independent validation of the results presented. This manuscript has not yet undergone independent peer review and should not be regarded as an established resolution of the stated problem unless and until its arguments have been examined and confirmed by qualified mathematicians. Independent verification, criticism, replication, and identification of errors are expressly invited.

## License

Research text, original mathematical figures, and documentation are licensed under **CC BY 4.0**. Verification code, build utilities, and figure-generation software are licensed under the **MIT License**. Metriq and PRISM names, marks, logos, publication lockups, and trade dress are excluded from those grants.
