# Changelog

## Version 1.0 — 16 July 2026

- Initial release of MF-MATH-2026-09.
- Derived the exact Bessel exponential generating function for type-ace walks.
- Derived a third-order annihilating differential operator.
- Proved the exact Ore factorization implying Mathar's conjectured recurrence.
- Added a lower-order companion recurrence.
- Added exact verification through `n = 80`, reproducible figures, PRISM branding, review guide, licensing, and QA records.
