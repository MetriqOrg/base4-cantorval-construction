# Source Problem and Citation

**Source:** Achievement Sets - Current Results and Open Problems  
**URL:** https://arxiv.org/abs/2512.17285

## Problem context

Problem 4, the Second Jones Problem, asks for a sequence whose consecutive-term ratio has a limit and whose achievement set is a Cantorval.

## Reviewer task

Confirm the exact source wording, intended scope, and whether the candidate theorem actually answers that problem or conjecture. Search for equivalent prior formulations and results.
