#!/usr/bin/env python3
"""Exact-arithmetic consistency checks for MF-MATH-2026-03.

These checks support the explicit binary example in the paper. They do not
replace the symbolic proof of the general theorem.
"""

from __future__ import annotations

from math import factorial
from typing import Iterable


def subset_sums(weights: Iterable[int]) -> set[int]:
    sums = {0}
    for weight in weights:
        sums |= {x + weight for x in sums}
    return sums


def factorial_block_positions(block_count: int) -> tuple[list[int], list[int], int]:
    """Return odd-block positions A, even-block positions B, and last position."""
    if block_count < 1:
        raise ValueError("block_count must be positive")

    a_positions: list[int] = []
    b_positions: list[int] = []
    endpoint = 0

    for block_index in range(1, block_count + 1):
        length = factorial(block_index)
        positions = list(range(endpoint + 1, endpoint + length + 1))
        if block_index % 2:
            a_positions.extend(positions)
        else:
            b_positions.extend(positions)
        endpoint += length

    return a_positions, b_positions, endpoint


def verify_finite_binary_recombination() -> None:
    # The first three factorial blocks have lengths 1, 2, and 6, so N = 9.
    # This permits complete enumeration of all 2^9 dyadic cells.
    a_positions, b_positions, n = factorial_block_positions(3)
    assert set(a_positions).isdisjoint(b_positions)
    assert sorted(a_positions + b_positions) == list(range(1, n + 1))

    a_weights = [1 << (n - pos) for pos in a_positions]
    b_weights = [1 << (n - pos) for pos in b_positions]

    a_sums = subset_sums(a_weights)
    b_sums = subset_sums(b_weights)
    combined = {x + y for x in a_sums for y in b_sums}

    expected = set(range(1 << n))
    assert combined == expected
    assert len(a_sums) == 1 << len(a_positions)
    assert len(b_sums) == 1 << len(b_positions)

    print("FINITE BINARY RECOMBINATION")
    print(f"  factorial blocks checked: 1!, 2!, 3!")
    print(f"  digit positions: 1..{n}")
    print(f"  A positions: {a_positions}")
    print(f"  B positions: {b_positions}")
    print(f"  |C_A prefix| = {len(a_sums)}")
    print(f"  |C_B prefix| = {len(b_sums)}")
    print(f"  |C_A + C_B prefix| = {len(combined)} = 2^{n}")
    print(f"  attained numerators: 0..{(1 << n) - 1} over denominator 2^{n}")
    print("  status: PASS\n")


def verify_factorial_checkpoint_growth(max_r: int = 10) -> None:
    print("FACTORIAL CHECKPOINT RATIOS")
    print("  r | p_r | M_(2r)/p_r | q_r | M_(2r+1)/q_r")
    print("  --+-----+------------+-----+----------------")

    p = 0
    q = 0
    for r in range(1, max_r + 1):
        p += factorial(2 * r - 1)
        q += factorial(2 * r)
        m_even = sum(factorial(j) for j in range(1, 2 * r + 1))
        m_odd = m_even + factorial(2 * r + 1)

        # Inequalities used in the manuscript.
        if r >= 2:
            assert p <= 2 * factorial(2 * r - 1)
        assert q <= 2 * factorial(2 * r)

        ratio_a = m_even / p
        ratio_b = m_odd / q
        print(
            f"  {r:2d} | {p:>5d} | {ratio_a:>10.6f} | "
            f"{q:>5d} | {ratio_b:>14.6f}"
        )

    print("  lower bounds used in the paper:")
    print("    M_(2r)/p_r >= r for r >= 2")
    print("    M_(2r+1)/q_r >= (2r+1)/2")
    print("  both checkpoint ratios diverge to infinity")
    print("  status: PASS\n")


def verify_adaptive_geometric_checkpoints(rounds: int = 4) -> None:
    """Check the recursive index bookkeeping for a_n = 2^{-n}.

    Here the original tail after N terms is exactly 2^{-N}. Choosing an
    endpoint N >= m^2 therefore enforces r_N <= 2^{-m^2} exactly.
    """
    endpoints = [0, 1]
    print("ADAPTIVE BLOCK CHECKPOINTS FOR a_n = 2^{-n}")

    for k in range(1, rounds + 1):
        p_k = sum(
            endpoints[2 * j - 1] - endpoints[2 * j - 2]
            for j in range(1, k + 1)
        )
        n_even = max(endpoints[-1] + 1, p_k * p_k)
        endpoints.append(n_even)
        assert n_even >= p_k * p_k

        q_k = sum(
            endpoints[2 * j] - endpoints[2 * j - 1]
            for j in range(1, k + 1)
        )
        n_odd = max(endpoints[-1] + 1, q_k * q_k)
        endpoints.append(n_odd)
        assert n_odd >= q_k * q_k

        print(
            f"  k={k}: p_k={p_k}, N_(2k)={n_even}; "
            f"q_k={q_k}, N_(2k+1)={n_odd}"
        )

    print("  every block is nonempty and both tail targets are met")
    print("  status: PASS\n")


def main() -> None:
    verify_finite_binary_recombination()
    verify_factorial_checkpoint_growth()
    verify_adaptive_geometric_checkpoints()
    print("ALL EXACT-ARITHMETIC CHECKS PASSED")


if __name__ == "__main__":
    main()
