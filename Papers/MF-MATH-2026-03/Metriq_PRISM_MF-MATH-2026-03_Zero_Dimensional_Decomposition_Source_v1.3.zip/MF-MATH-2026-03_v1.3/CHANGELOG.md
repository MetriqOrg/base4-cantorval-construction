# Changelog - MF-MATH-2026-03

## Version 1.3 - 16 July 2026

Metriq PRISM Laboratory edition; updated cover and masthead, institutional disclaimer, release metadata, licensing, checksums, and package organization. No mathematical claim was changed.

## Version 1.2 - 15 July 2026

Integrated audited proof strengthening: full absolutely summable real-sequence theorem, zero-term pullback, explicit Hausdorff-measure quantifiers, signed Cantor-set proof, and clarified multifactor and binary-model arguments.

## Version 1.1 - 15 July 2026

Interim audit revision clarifying absolute-tail estimates and exact recombination.

## Version 1.0 - 15 July 2026

Initial candidate preprint.
