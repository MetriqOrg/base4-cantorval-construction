# Proof dependency map

1. Coordinate enumeration gives Catalan numbers for type `a`, central binomial prefixes for type `c`, and `2^n` for type `e`.
2. Labelled interleaving multiplies the three exponential generating functions.
3. Modified-Bessel identities give a first-order system for `I0(2x)` and `I1(2x)`.
4. Symmetric-square elimination yields the displayed third-order operator `L3` annihilating `F`.
5. Exact Ore multiplication proves `(8x+3)^3 L6 = Q o L3`.
6. Because `(8x+3)^3` is invertible as a formal power series, `L6 F = 0`.
7. EGF coefficient extraction produces Mathar's recurrence for every `n >= 4`.

A failure at any step invalidates the claimed proof even if all finite sequence checks pass.
