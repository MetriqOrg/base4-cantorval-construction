#!/usr/bin/env python3
"""Exact verification for MF-MATH-2026-09.

The script independently checks:
  1. the type-ace EGF coefficients from coordinate counts;
  2. Mathar's conjectured recurrence for n >= 4;
  3. the companion recurrence obtained from the third-order operator;
  4. the exact Ore-operator factorization (8x+3)^3 L6 = Q o L3.
"""
from __future__ import annotations

from math import comb, factorial
from pathlib import Path
from typing import Dict

import sympy as sp


def catalan(m: int) -> int:
    return comb(2 * m, m) // (m + 1)


def type_a_count(r: int) -> int:
    return catalan(r // 2) if r % 2 == 0 else 0


def type_c_count(s: int) -> int:
    return comb(s, s // 2)


def type_e_count(t: int) -> int:
    return 2**t


def ace_count(n: int) -> int:
    total = 0
    nf = factorial(n)
    for r in range(n + 1):
        ar = type_a_count(r)
        if ar == 0:
            continue
        for s in range(n - r + 1):
            t = n - r - s
            multinomial = nf // (factorial(r) * factorial(s) * factorial(t))
            total += multinomial * ar * type_c_count(s) * type_e_count(t)
    return total


def mathar_residual(a: list[int], n: int) -> int:
    return (
        (n + 3) * (n + 2) * a[n]
        + 4 * (-3 * n * n - 8 * n - 3) * a[n - 1]
        + 8 * (4 * n * n + 3 * n - 3) * a[n - 2]
        + 48 * (n - 2) ** 2 * a[n - 3]
        - 144 * (n - 2) * (n - 3) * a[n - 4]
    )


def companion_residual(a: list[int], n: int) -> int:
    return (
        3 * (n + 2) * (n + 3) * a[n]
        + 2 * (4 * n**3 - 5 * n**2 - 37 * n - 16) * a[n - 1]
        - 4 * (n - 1) * (12 * n**2 + 7 * n - 14) * a[n - 2]
        - 8 * (n - 1) * (n - 2) * (4 * n - 25) * a[n - 3]
        + 192 * (n - 1) * (n - 2) * (n - 3) * a[n - 4]
    )


def ore_compose(A: Dict[int, sp.Expr], B: Dict[int, sp.Expr], x: sp.Symbol) -> Dict[int, sp.Expr]:
    """Compose scalar differential operators A o B in normal form."""
    out: Dict[int, sp.Expr] = {}
    for i, ai in A.items():
        for j, bj in B.items():
            for k in range(i + 1):
                order = i - k + j
                term = ai * comb(i, k) * sp.diff(bj, x, k)
                out[order] = sp.expand(out.get(order, 0) + term)
    return {q: sp.factor(v) for q, v in out.items() if sp.expand(v) != 0}


def scaled_operator(A: Dict[int, sp.Expr], scalar: sp.Expr) -> Dict[int, sp.Expr]:
    return {k: sp.expand(scalar * v) for k, v in A.items()}


def check_operator_factorization() -> None:
    x = sp.symbols("x")
    L3 = {
        3: x**2 * (8 * x + 3),
        2: -2 * x * (24 * x**2 - 19 * x - 12),
        1: -4 * (8 * x**3 + 67 * x**2 + 12 * x - 9),
        0: 4 * (48 * x**3 + 26 * x**2 - 48 * x - 27),
    }
    L6 = {
        6: x**2,
        5: -2 * x * (6 * x - 7),
        4: 2 * (16 * x**2 - 70 * x + 21),
        3: 4 * (12 * x**2 + 78 * x - 83),
        2: -8 * (18 * x**2 - 30 * x - 73),
        1: -192 * (3 * x - 1),
        0: -288,
    }
    Q = {
        3: (8 * x + 3) ** 2,
        2: -2 * (24 * x + 17) * (8 * x + 3),
        1: 32 * (24 * x + 13),
        0: -768,
    }
    lhs = scaled_operator(L6, (8 * x + 3) ** 3)
    rhs = ore_compose(Q, L3, x)
    all_orders = set(lhs) | set(rhs)
    errors = {k: sp.expand(lhs.get(k, 0) - rhs.get(k, 0)) for k in all_orders}
    assert all(v == 0 for v in errors.values()), errors


def main() -> None:
    N = 80
    a = [ace_count(n) for n in range(N + 1)]
    expected = [1, 3, 11, 44, 188, 842, 3911, 18692, 91412, 455540, 2306028, 11829424]
    assert a[: len(expected)] == expected

    for n in range(4, N + 1):
        assert mathar_residual(a, n) == 0, (n, mathar_residual(a, n))
        assert companion_residual(a, n) == 0, (n, companion_residual(a, n))

    check_operator_factorization()

    print("MF-MATH-2026-09 exact verification")
    print("Initial coefficients:", a[:12])
    print(f"Coordinate-count EGF coefficients checked through n={N}.")
    print(f"Mathar recurrence residuals vanish for 4 <= n <= {N}.")
    print(f"Third-order companion recurrence residuals vanish for 4 <= n <= {N}.")
    print("Ore factorization verified exactly:")
    print("  (8x+3)^3 L6 = Q o L3")
    print("All exact checks passed.")


if __name__ == "__main__":
    main()
