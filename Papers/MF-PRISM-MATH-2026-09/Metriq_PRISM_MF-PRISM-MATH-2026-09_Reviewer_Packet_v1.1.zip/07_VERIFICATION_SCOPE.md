# Verification scope

`verification/verify_type_ace.py` uses exact integer and rational arithmetic and requires only the Python standard library. It checks:

- initial coefficients from the three coordinate sequences;
- Mathar's recurrence for `n = 4..100`;
- the companion recurrence for `n = 4..100`;
- formal-series annihilation by `L3` and `L6` through degree 74;
- the Ore identity exactly over the differential-operator ring.

`verification/verify_type_ace_sympy.py` is the preserved predecessor-package verifier. It independently checks coefficients and both recurrences through `n = 80` and the Ore factorization using SymPy.

These programs audit encoded algebra. They do not establish unencoded reasoning, novelty, priority, or peer-review status.
