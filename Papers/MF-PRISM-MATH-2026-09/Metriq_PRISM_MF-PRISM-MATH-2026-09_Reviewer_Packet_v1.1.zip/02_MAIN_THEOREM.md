# Main theorem under review

Let `a_n` count three-dimensional nearest-neighbor walks whose coordinate types are `a`, `c`, and `e` in Dershowitz's terminology. The manuscript claims that Mathar's five-term recurrence recorded for OEIS A302186 holds for every integer `n >= 4`.

The proof derives the exact Bessel exponential generating function, obtains a third-order annihilator `L3`, proves the noncommutative identity `(8x+3)^3 L6 = Q o L3`, and extracts the claimed recurrence from `L6 F = 0`.

Review must address the infinite proof, not only the finite exact checks.
