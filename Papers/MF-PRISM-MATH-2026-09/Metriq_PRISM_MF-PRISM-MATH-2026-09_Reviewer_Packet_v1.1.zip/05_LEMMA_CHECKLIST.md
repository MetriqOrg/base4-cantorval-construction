# Lemma and calculation checklist

- [ ] Confirm the one-dimensional counts for coordinate types `a`, `c`, and `e`.
- [ ] Confirm their exponential generating functions.
- [ ] Verify that labelled coordinate interleaving gives the product formula for `F`.
- [ ] Re-derive the Bessel derivative system.
- [ ] Check the symmetric-square matrix and observability determinant.
- [ ] Eliminate the state variables and reproduce the scalar ODE.
- [ ] Check the gauge transformation from `z` to `F`.
- [ ] Expand `Q o L3` with the noncommutative rule `D x = x D + 1`.
- [ ] Confirm the factor `(8x+3)^3` can be canceled in the formal-series ring.
- [ ] Extract coefficients from `L6 F = 0` and recover the recurrence exactly.
- [ ] Check the lower-order companion recurrence.
- [ ] Assess novelty and prior art separately from mathematical correctness.
