# Source problem and citation

The motivating record is OEIS A302186, "Number of 3D walks of type ace." The recurrence was contributed by R. J. Mathar on 29 October 2025 and was labeled conjectural when inspected on 16 July 2026.

The coordinate-type framework is attributed to Nachum Dershowitz, "Touchard's Drunkard," *Journal of Integer Sequences* 20 (2017), Article 17.1.5; arXiv:1612.04076.

Reviewers should verify the type-`a`, type-`c`, and type-`e` interpretations against the source literature and search for equivalent holonomic, Bessel, or creative-telescoping arguments that may not use the phrase "type ace" or sequence number A302186.
