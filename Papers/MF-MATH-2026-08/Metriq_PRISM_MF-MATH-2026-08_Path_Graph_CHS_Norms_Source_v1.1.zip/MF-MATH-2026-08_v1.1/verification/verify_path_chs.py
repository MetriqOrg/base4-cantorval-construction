#!/usr/bin/env python3
"""Exact verification for MF-MATH-2026-08.

Checks the endpoint-walk, reciprocal-determinant, reflection-sum, and
short-range formulas for the complete homogeneous symmetric (CHS) norms
of path graphs.  Only Python's standard library is required.
"""

from __future__ import annotations

from fractions import Fraction
from math import comb


def C(n: int, k: int) -> int:
    """Binomial coefficient with the usual zero-outside-range convention."""
    return comb(n, k) if 0 <= k <= n else 0


def endpoint_walk_count(n: int, m: int) -> int:
    """Walks of length n-1+2m from vertex 1 to vertex n in P_n."""
    if n < 1 or m < 0:
        raise ValueError("n must be positive and m nonnegative")
    length = n - 1 + 2 * m
    state = [0] * n
    state[0] = 1
    for _ in range(length):
        nxt = [0] * n
        for v, count in enumerate(state):
            if v > 0:
                nxt[v - 1] += count
            if v + 1 < n:
                nxt[v + 1] += count
        state = nxt
    return state[n - 1]


def determinant_coefficients(n: int) -> list[int]:
    """Coefficients of det(I-tA(P_n)) as a polynomial in z=t^2."""
    return [(-1) ** r * C(n - r, r) for r in range(n // 2 + 1)]


def reciprocal_coefficients(n: int, max_m: int) -> list[int]:
    """Coefficients a_m of 1/det(I-tA(P_n)) = sum a_m t^(2m)."""
    den = determinant_coefficients(n)
    a = [0] * (max_m + 1)
    a[0] = 1
    for m in range(1, max_m + 1):
        # Since den[0]=1, convolution with the reciprocal vanishes in degree m.
        a[m] = -sum(den[r] * a[m - r] for r in range(1, min(m, len(den) - 1) + 1))
    return a


def reflection_sum(n: int, m: int) -> int:
    """Finite method-of-images formula from the paper's main theorem."""
    N = n + 1
    L = n - 1 + 2 * m
    j_min = -(m // N)
    j_max = 1 + ((m - 1) // N) if m >= 1 else 0
    return sum(C(L, m + j * N) - C(L, m - 1 + j * N) for j in range(j_min, j_max + 1))


def short_range_formula(n: int, m: int) -> Fraction:
    """Closed form valid when m < n+1."""
    d = 2 * m
    return Fraction(n * n + n - d, (n + d) * (n + d + 1)) * C(n + d + 1, m)


def boundary_formula(n: int) -> Fraction:
    """Corrected equality case m=n+1: short-range expression plus one."""
    m = n + 1
    return short_range_formula(n, m) + 1


def audit(max_n: int = 24, max_m: int = 48) -> None:
    checked = 0
    for n in range(1, max_n + 1):
        reciprocal = reciprocal_coefficients(n, max_m)
        for m in range(0, max_m + 1):
            walk = endpoint_walk_count(n, m)
            image = reflection_sum(n, m) if m >= 1 else 1
            assert walk == reciprocal[m], ("walk/reciprocal", n, m, walk, reciprocal[m])
            assert walk == image, ("walk/reflection", n, m, walk, image)
            if 1 <= m < n + 1:
                rhs = short_range_formula(n, m)
                assert rhs.denominator == 1 and rhs.numerator == walk, (
                    "short-range", n, m, walk, rhs
                )
            if m == n + 1:
                rhs = boundary_formula(n)
                assert rhs.denominator == 1 and rhs.numerator == walk, (
                    "boundary", n, m, walk, rhs
                )
            checked += 1

    print("MF-MATH-2026-08 exact verification")
    print(f"Checked {checked} parameter pairs: 1 <= n <= {max_n}, 0 <= m <= {max_m}.")
    print("All endpoint-walk, determinant-reciprocal, and reflection identities agree.")
    print("The closed form agrees throughout the strict range m < n+1.")
    print("The corrected equality case m=n+1 agrees after adding the missing image term 1.")
    print()
    print("Boundary-condition audit (the non-strict version fails):")
    for n in range(1, 6):
        m = n + 1
        exact = endpoint_walk_count(n, m)
        proposed_non_strict = short_range_formula(n, m)
        corrected = boundary_formula(n)
        print(
            f"  n={n:2d}, d={2*m:2d}: exact={exact:6d}, "
            f"non-strict RHS={str(proposed_non_strict):>6s}, corrected={str(corrected):>6s}"
        )

    print()
    print("Sample values a_{n,m}=||P_n||_{X,2m}^{2m} (m=0,...,8):")
    for n in range(1, 9):
        vals = reciprocal_coefficients(n, 8)
        print(f"  n={n}: " + ", ".join(str(v) for v in vals))


if __name__ == "__main__":
    audit()
