# Changelog - MF-MATH-2026-08

## Version 1.1 - 16 July 2026

Metriq PRISM Laboratory edition; updated cover and masthead, institutional disclaimer, release metadata, licensing, checksums, and package organization. No mathematical claim was changed.

## Version 1.0 - 15 July 2026

Initial candidate preprint.
