# Endpoint Walks Evaluate the Complete Homogeneous Symmetric Norms of Path Graphs

**Issuer:** Metriq PRISM Laboratory  
**Expanded name:** Program for Research in Intelligent Systems and Methods  
**Ownership:** A research laboratory of Metriq Foundation, Inc.  
**Identifier:** MF-MATH-2026-08  
**Version:** 1.1  
**Release date:** 16 July 2026  
**Status:** Candidate research preprint; not independently peer reviewed

## Candidate result

A spectral-graph-theory paper identifying path-graph complete homogeneous symmetric norms with endpoint-to-endpoint walk counts and deriving the conjectured trigonometric and reflection formulas.

For the path graph P_n and m>=0, the manuscript proves h_(2m)(lambda(P_n))=(A(P_n)^(n-1+2m))_(1n), derives the exact spectral and binomial formulas, and corrects a finite-support boundary condition in the motivating conjecture.

## Review status

Exact computational consistency checks cover 1,176 parameter pairs; independent specialist review and publication-priority review remain outstanding.

The exact finite computations supplied with the package are reproducibility and
consistency checks. They do not constitute independent validation of the
infinite arguments, novelty, or publication priority.

## Package contents

- `metriq_path_graph_chs_norms_preprint.tex` - complete LuaLaTeX manuscript source
- `release/Metriq_PRISM_MF-MATH-2026-08_Path_Graph_CHS_Norms_v1.1.pdf` - final PRISM-branded PDF
- `release/Metriq_PRISM_MF-MATH-2026-08_Path_Graph_CHS_Norms_Cover_v1.1.png` - final cover rendered from page 1 at 300 dpi
- `figures/` - formula-derived figures used in the manuscript
- `assets/` - PRISM publication lockups used by the source
- `verification/` - exact or high-precision consistency checks and recorded output
- `REVIEW_GUIDE.md` - targeted independent-review checklist
- `CITATION.cff` - machine-readable citation metadata
- `CHANGELOG.md` - version history and supersession notes
- `DISCLAIMER.txt` - institutional and computational-research disclaimer
- `LICENSE*` and `TRADEMARKS.md` - split licensing and brand restrictions
- `QA/` - PDF metadata, font, preflight, and renderer-parity reports

## Build

A current LuaLaTeX distribution is required. The included figures are already
built.

```bash
make paper
```

The rebuilt PDF is written to `build/`.

To regenerate the figures, install numpy, matplotlib, then run:

```bash
python3 generate_figures.py
```

## Verification

```bash
python3 verification/verify_path_chs.py
```

The recorded output is in `verification/verification_output.txt`.

## Institutional disclaimer and computational research declaration

This manuscript is an exploratory research preprint issued by the Metriq PRISM Laboratory, an interdisciplinary research laboratory of Metriq Foundation, Inc. PRISM—the Program for Research in Intelligent Systems and Methods—conducts research involving computational, mathematical, scientific, and machine-assisted methods.

The work was developed as part of PRISM’s experimental research program in computationally assisted mathematics. Metriq Foundation, acting through the PRISM Laboratory, directed the research process, evaluated the resulting argument, determined the form and scope of the manuscript, and accepts responsibility for its publication as a candidate result.

Generative artificial intelligence and other computational tools were used as research instruments to support construction search, symbolic and numerical analysis, literature review, proof development, verification, and manuscript preparation. Their use does not constitute independent validation of the results presented.

This manuscript has not yet undergone independent peer review and should not be regarded as an established resolution of the stated problem unless and until its arguments have been examined and confirmed by qualified mathematicians. Independent verification, criticism, replication, and identification of errors are expressly invited.

## License

Research text, original mathematical figures, and documentation are licensed
under **CC BY 4.0**. Verification code, build utilities, and figure-generation
software are licensed under the **MIT License**. Metriq and PRISM names, marks,
logos, publication lockups, and trade dress are excluded from those grants.
