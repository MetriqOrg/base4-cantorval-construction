# Changelog - MF-MATH-2026-01

## Version 1.2 - 16 July 2026

Metriq PRISM Laboratory edition; updated cover and masthead, institutional disclaimer, release metadata, licensing, checksums, and package organization. No mathematical claim was changed.

## Version 1.1 - 15 July 2026

Integrated audited proof revisions: explicit compactness and Baire-category step, corrected classification citation, exact tail/gap presentation, and tightened priority language.

## Version 1.0 - 15 July 2026

Initial candidate preprint.
