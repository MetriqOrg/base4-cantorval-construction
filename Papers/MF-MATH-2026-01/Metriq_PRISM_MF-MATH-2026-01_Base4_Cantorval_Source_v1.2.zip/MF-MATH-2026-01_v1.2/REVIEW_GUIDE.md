# Independent Mathematical Review Guide

## MF-MATH-2026-01 - An Explicit Cantorval Achievement Set with Convergent Consecutive-Term Ratio

**Version reviewed:** 1.2  
**Issuer:** Metriq PRISM Laboratory, a research laboratory of Metriq Foundation, Inc.  
**Status:** Candidate result; not independently peer reviewed

## Central claim

For x_(2n-1)=(8n+17)/4^n and x_(2n)=(4n+18)/4^n, the manuscript proves that the achievement set is a Cantorval and that x_(k+1)/x_k tends to 1/2.

## Load-bearing review targets

1. Verify the complete-residue-system argument and the finite-union Baire-category step establishing nonempty interior.
2. Verify the exact tail identity r_(2n)=(4n+17)/4^n and the gap interval (r_(2n),x_(2n)).
3. Confirm the hypotheses and use of the corrected Guthrie-Nymann classification theorem.
4. Search for equivalent constructions under scaling, blocking, or reindexing and confirm the historical formulation of the Second Jones Problem.

## Review format requested

A useful review should identify the exact theorem, lemma, equation, figure, or
page involved; distinguish fatal, repairable, and expository issues; and supply
a counterexample, correction, independent derivation, or prior-art reference
where possible. Computational checks should be reported separately from review
of the infinite argument.

## Scope limitation

A successful reproduction of the included scripts does not establish the
candidate theorem, novelty, or priority. Independent mathematical reading is
required.
