# Proof Dependency Map

1. **Coefficient identity** - Identify subset-sum multiplicities with coefficients of product_i(1+z^(x_i)).
2. **Three finite certificates** - Expand or enumerate the generating polynomials and read off the positive coefficient ranges.
3. **Unique ternary tail** - Prove the tail has unique representations and diameter less than one.
4. **Disjoint translates** - Use integer prefix sums and a tail in [0,1/2] to prevent overlap between distinct translates.
5. **Cantorization** - Conclude that multiplicities are preserved and the infinite achievement set is a Cantor set.
