# Known Risk Points

## Internal risk level

**Low to moderate**

## Questions requiring adversarial review

1. Do the three sequences fill exactly the intended blank finite/Cantor cases?
2. Does the ternary-tail argument preserve every multiplicity without any translate overlap?
3. Are equivalent witnesses already known or discoverable by prior exhaustive searches?
4. Is the resulting classification update stated with the correct class inclusions?

## Required corrections already identified

- State explicitly that the range is taken over attained sums, equivalently over positive coefficients of the generating polynomial.
- Include the full coefficient vectors and machine-readable enumeration output in the reviewer packet.
- Ask the source-paper authors to confirm that the table blanks have the interpretation used here.
- Update identifier, metadata, correspondence, DOI placeholder, and preferred citation.
