# Independent Mathematical Review Guide

## MF-MATH-2026-04 - An Achievable Cantorval with Zero-Dimensional Boundary

**Version reviewed:** 1.1  
**Issuer:** Metriq PRISM Laboratory, a research laboratory of Metriq Foundation, Inc.  
**Status:** Candidate result; not independently peer reviewed

## Central claim

The block sequence with one term 3/Q_n and n copies of 2/Q_n, where Q_n=2^n(n+1)!, is claimed to generate a Cantorval E with dim_H(partial E)=0.

## Load-bearing review targets

1. Verify the complete residue and symmetry properties of the block digit system.
2. Audit the nested outer approximations and the derivation of the explicit central interval.
3. Check the accumulating-gap argument, boundary state recursion, and equality between the stated boundary pieces and recursive states.
4. Verify the 2*3^N cylinder count, diameter bound 2/(3Q_N), and the Hausdorff-dimension-zero conclusion.
5. Review the even-base generalization and search for prior variable-base boundary constructions.

## Review format requested

A useful review should identify the exact theorem, lemma, equation, figure, or
page involved; distinguish fatal, repairable, and expository issues; and supply
a counterexample, correction, independent derivation, or prior-art reference
where possible. Computational checks should be reported separately from review
of the infinite argument.

## Scope limitation

A successful reproduction of the included scripts does not establish the
candidate theorem, novelty, or priority. Independent mathematical reading is
required.
