# An Achievable Cantorval with Zero-Dimensional Boundary

**Issuer:** Metriq PRISM Laboratory  
**Expanded name:** Program for Research in Intelligent Systems and Methods  
**Ownership:** A research laboratory of Metriq Foundation, Inc.  
**Identifier:** MF-MATH-2026-04  
**Version:** 1.1  
**Release date:** 16 July 2026  
**Status:** Candidate research preprint; not independently peer reviewed

## Candidate result

A factorial mixed-radix construction proposed to produce an achievable Cantorval whose boundary has Hausdorff dimension zero.

The block sequence with one term 3/Q_n and n copies of 2/Q_n, where Q_n=2^n(n+1)!, is claimed to generate a Cantorval E with dim_H(partial E)=0.

## Review status

Internal proof audit found no mathematical correction required; independent specialist review and publication-priority review remain outstanding.

The exact finite computations supplied with the package are reproducibility and
consistency checks. They do not constitute independent validation of the
infinite arguments, novelty, or publication priority.

## Package contents

- `metriq_zero_dimensional_boundary_preprint.tex` - complete LuaLaTeX manuscript source
- `release/Metriq_PRISM_MF-MATH-2026-04_Zero_Dimensional_Cantorval_Boundary_v1.1.pdf` - final PRISM-branded PDF
- `release/Metriq_PRISM_MF-MATH-2026-04_Zero_Dimensional_Cantorval_Boundary_Cover_v1.1.png` - final cover rendered from page 1 at 300 dpi
- `figures/` - formula-derived figures used in the manuscript
- `assets/` - PRISM publication lockups used by the source
- `verification/` - exact or high-precision consistency checks and recorded output
- `REVIEW_GUIDE.md` - targeted independent-review checklist
- `CITATION.cff` - machine-readable citation metadata
- `CHANGELOG.md` - version history and supersession notes
- `DISCLAIMER.txt` - institutional and computational-research disclaimer
- `LICENSE*` and `TRADEMARKS.md` - split licensing and brand restrictions
- `QA/` - PDF metadata, font, preflight, and renderer-parity reports

## Build

A current LuaLaTeX distribution is required. The included figures are already
built.

```bash
make paper
```

The rebuilt PDF is written to `build/`.

To regenerate the figures, install numpy, matplotlib, Pillow, mpmath, then run:

```bash
python3 generate_figures.py
```

## Verification

```bash
python3 verify_construction.py
```

The recorded output is in `verification/verification_output.txt`.

## Institutional disclaimer and computational research declaration

This manuscript is an exploratory research preprint issued by the Metriq PRISM Laboratory, an interdisciplinary research laboratory of Metriq Foundation, Inc. PRISM—the Program for Research in Intelligent Systems and Methods—conducts research involving computational, mathematical, scientific, and machine-assisted methods.

The work was developed as part of PRISM’s experimental research program in computationally assisted mathematics. Metriq Foundation, acting through the PRISM Laboratory, directed the research process, evaluated the resulting argument, determined the form and scope of the manuscript, and accepts responsibility for its publication as a candidate result.

Generative artificial intelligence and other computational tools were used as research instruments to support construction search, symbolic and numerical analysis, literature review, proof development, verification, and manuscript preparation. Their use does not constitute independent validation of the results presented.

This manuscript has not yet undergone independent peer review and should not be regarded as an established resolution of the stated problem unless and until its arguments have been examined and confirmed by qualified mathematicians. Independent verification, criticism, replication, and identification of errors are expressly invited.

## License

Research text, original mathematical figures, and documentation are licensed
under **CC BY 4.0**. Verification code, build utilities, and figure-generation
software are licensed under the **MIT License**. Metriq and PRISM names, marks,
logos, publication lockups, and trade dress are excluded from those grants.
