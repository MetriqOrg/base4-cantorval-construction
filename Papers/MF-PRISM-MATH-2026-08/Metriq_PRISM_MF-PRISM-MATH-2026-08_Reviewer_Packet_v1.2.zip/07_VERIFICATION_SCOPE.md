# Verification Scope

## What was checked

- The endpoint cofactor calculation is correct: the minor is triangular with product (-t)^(n-1), and the cofactor sign produces t^(n-1).
- Coefficient comparison yields the stated shift n-1+r and gives a direct walk interpretation.
- The spectral formula follows from the standard sine eigenbasis of a path.
- The two-barrier image formula and its reindexing were checked against dynamic programming.
- The exact support bounds include j=-m/(n+1) when n+1 divides m; omitting that term lowers the equality case by exactly one.
- The included exact verifier compared endpoint walks, determinant coefficients, reflection sums, and corrected formulas for 1,176 parameter pairs.

## What the computation does not establish

- novelty or publication priority;
- correctness of unencoded infinite arguments;
- correctness of the source-problem interpretation;
- applicability of external classification or dimension theorems unless those hypotheses are separately checked;
- journal-level peer review.

## Included verifier

`verification/verify_path_chs.py`

The rerun output is included in `verification/verification_output.txt`.
