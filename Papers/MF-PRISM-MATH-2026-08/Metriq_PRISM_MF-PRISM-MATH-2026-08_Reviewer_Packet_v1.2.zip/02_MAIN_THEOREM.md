# Main Theorem - MF-PRISM-MATH-2026-08

For the path graph P_n, h_r(lambda(P_n))=(A_n^(n-1+r))_(1,n). For even r=2m this gives the CHS norm as an endpoint-walk count, from which the conjectured spectral and reflection formulas follow; the paper also corrects the equality boundary in the source remark.
