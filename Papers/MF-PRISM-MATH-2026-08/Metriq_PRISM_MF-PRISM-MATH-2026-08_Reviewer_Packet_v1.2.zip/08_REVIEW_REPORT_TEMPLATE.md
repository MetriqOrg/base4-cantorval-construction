# Independent Review Report Template

**Paper:** MF-PRISM-MATH-2026-08  
**Version reviewed:**  
**Reviewer:**  
**Affiliation / expertise:**  
**Date:**  
**Conflict of interest:**  

## Assessment

- [ ] Correct as stated
- [ ] Correct after minor revision
- [ ] Potentially correct, but a major gap remains
- [ ] Incorrect
- [ ] Unable to determine

## Scope of review

List the sections, lemmas, computations, and references actually checked.

## Detailed objections or confirmations

Provide page, theorem, equation, or line references.

## Counterexample attempts

Describe degenerate cases, boundary cases, or counterexamples considered.

## Prior art and problem interpretation

State whether the source problem is quoted accurately and identify any equivalent prior result.

## Required revisions

List every issue that must be resolved before submission.

## Permission

- [ ] PRISM may identify me publicly as a reviewer.
- [ ] PRISM may publish my report.
- [ ] Keep my identity and report confidential.
