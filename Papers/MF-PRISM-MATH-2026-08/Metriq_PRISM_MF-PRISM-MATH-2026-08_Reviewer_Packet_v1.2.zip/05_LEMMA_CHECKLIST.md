# Lemma and Claim Checklist

Use **Confirmed**, **Objection**, **Not checked**, or **Not applicable**.

| # | Claim / step | Reviewer status | Notes |
|---:|---|---|---|
| 1 | **Endpoint resolvent lemma:** Compute the (1,n) cofactor of I-tA_n and obtain t^(n-1)/det(I-tA_n). |  |  |
| 2 | **Coefficient comparison:** Compare the matrix resolvent series with the CHS generating function. |  |  |
| 3 | **Spectral evaluation:** Insert path eigenvalues and endpoint eigenvector coordinates. |  |  |
| 4 | **Two-barrier image formula:** Count endpoint walks with signed reflection images. |  |  |
| 5 | **Exact support and correction:** Determine all nonzero image indices and isolate the omitted equality term. |  |  |
| 6 | **Generating function and recurrence:** Use the continuant determinant to obtain a rational generating function and finite recurrence. |  |  |

## Final implications

| Question | Response |
|---|---|
| Does every imported theorem apply under its exact hypotheses? |  |
| Does the main conclusion follow from the proved intermediate claims? |  |
| Is the source problem interpreted correctly? |  |
| Is the result novel to the best of the reviewer's knowledge? |  |
