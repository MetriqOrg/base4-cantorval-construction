#!/usr/bin/env python3
"""Exact checks for the variable-base Cantorval construction.

This script is supplementary only; the manuscript proof is analytic and does not
rely on numerical computation.
"""
from __future__ import annotations

from fractions import Fraction
from itertools import product
from math import log


def ell(n: int) -> int:
    return n + 1


def base(n: int) -> int:
    return 2 * ell(n) + 2  # 2n+4


def Q(n: int) -> int:
    q = 1
    for k in range(1, n + 1):
        q *= base(k)
    return q


def digits(n: int) -> tuple[int, ...]:
    l = ell(n)
    return tuple(range(0, 2 * l + 1, 2)) + tuple(range(2 * l + 1, 4 * l + 2, 2))


def boundary_digits(n: int) -> tuple[int, ...]:
    l = ell(n)
    return tuple(range(0, 2 * l, 2))


def block_total(n: int) -> Fraction:
    return Fraction(4 * ell(n) + 1, Q(n))


def tail_partial(n: int, cutoff: int) -> Fraction:
    return sum((block_total(k) for k in range(n + 1, cutoff + 1)), Fraction(0))


def verify_residues(max_n: int = 8) -> None:
    for n in range(1, max_n + 1):
        D = digits(n)
        b = base(n)
        assert len(D) == b
        assert {d % b for d in D} == set(range(b))


def verify_mixed_radix(max_N: int = 4) -> None:
    # N=4 has Q_4=5760 strings, so full enumeration remains small.
    for N in range(1, max_N + 1):
        qN = Q(N)
        residues: set[int] = set()
        prefixes: list[int] = []
        for ds in product(*(digits(k) for k in range(1, N + 1))):
            p = sum(ds[k - 1] * (qN // Q(k)) for k in range(1, N + 1))
            prefixes.append(p)
            residues.add(p % qN)
        assert len(prefixes) == qN
        assert len(set(prefixes)) == qN
        assert residues == set(range(qN))
        # Every prefix is less than 2Q_N, as follows analytically from total sum <2.
        assert min(prefixes) == 0
        assert max(prefixes) < 2 * qN


def verify_tail_bounds(max_n: int = 12, cutoff: int = 300) -> None:
    # The omitted positive tail makes this only a lower approximation to R_n,
    # but the exact analytic upper bound R_n < 2/Q_n is checked termwise by
    # telescoping in the manuscript. Here we verify a large finite portion.
    for n in range(0, max_n + 1):
        partial = tail_partial(n, cutoff)
        assert partial < Fraction(2, Q(n))
        if n >= 1:
            assert partial < Fraction(2, Q(n))


def verify_monotonic_blocks(max_n: int = 100) -> None:
    for n in range(1, max_n + 1):
        qn = Q(n)
        large = Fraction(2 * n + 3, qn)
        small = Fraction(2, qn)
        assert large > small > 0
        if n < max_n:
            next_large = Fraction(2 * (n + 1) + 3, Q(n + 1))
            assert small > next_large


def dimension_diagnostics(max_n: int = 200) -> list[tuple[int, float]]:
    m = 1
    q = 1
    out: list[tuple[int, float]] = []
    for n in range(1, max_n + 1):
        m *= ell(n)
        q *= base(n)
        if n in {2, 3, 5, 10, 20, 50, 100, 200}:
            out.append((n, log(m) / log(q)))
    return out


def main() -> None:
    verify_residues()
    verify_mixed_radix()
    verify_tail_bounds()
    verify_monotonic_blocks()

    print("Exact structural checks passed.")
    print("First blocks:")
    print(" n   ell_n   b_n       Q_n   |D_n|  |A_n|")
    for n in range(1, 8):
        print(f"{n:2d} {ell(n):7d} {base(n):5d} {Q(n):10d} {len(digits(n)):7d} {len(boundary_digits(n)):6d}")

    print("\nDimension diagnostics log(M_n)/log(Q_n):")
    for n, ratio in dimension_diagnostics():
        print(f"n={n:3d}: {ratio:.12f}")

    # Numerical total for orientation only.
    partial_total = sum((block_total(k) for k in range(1, 300)), Fraction(0))
    print(f"\nPartial total through block 299: {float(partial_total):.15f}")
    print("Analytic bound in manuscript: total < 2.")


if __name__ == "__main__":
    main()
