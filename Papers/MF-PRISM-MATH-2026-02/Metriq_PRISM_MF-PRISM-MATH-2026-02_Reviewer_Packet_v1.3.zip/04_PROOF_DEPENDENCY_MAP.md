# Proof Dependency Map

1. **Block and digit construction** - Establish summability and complete residue systems at every variable radix.
2. **Mixed-radix bijection and interior** - Use complete residues to force nonempty interior.
3. **Exact tail and gaps** - Produce infinitely many separated gaps and conclude the set is a Cantorval.
4. **Protected boundary subset C** - Choose lower-even digits and prove the resulting Moran-type set lies in the boundary.
5. **Separation and mass distribution** - Construct a probability measure on C and prove dim_H(C)=1.
6. **Main theorem** - Use C subset boundary E subset R to obtain dim_H(boundary E)=1.
